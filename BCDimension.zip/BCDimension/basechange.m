// The dimension of the base change part of the cuspidal space 
// is being calculated with the function allbcd(N, ell, k), where
// N is the level, ell is the prime discriminant (coprime to N) and
// k is the weight.
// To compare with the cohomology, add the Eisenstein contribution.

// Attention: Only prime discriminant > 3 is implemented correctly !!!!!!!!!!

load "CMs.m";
load "SigmaParameters.m";

BCParameters := function(N, ell)
  I_0, I_1, I_2 := I_all_bc(N, ell);
  CM_1 := NumberOfCMformsByK(N*ell, ell);
  CM_2 := NumberOfCMformsByK(N*ell^2, ell);
  return I_0, I_1, I_2, CM_1, CM_2;
end function;

BCDimension := function(I_0, I_1, I_2, CM_1, CM_2, k)
  if IsOdd(k) then
    return (I_1[1]*(k-1)/12 - I_1[2]/2 + I_1[3]*Mu(k) +I_1[4]*Epsilon(k) + I_1[5]*KroneckerDelta(k, 2) - CM_1) / 2;
  else
    return (I_0[1]*(k-1)/12 - I_0[2]/2 + I_0[3]*Mu(k) +I_0[4]*Epsilon(k) + I_0[5]*KroneckerDelta(k, 2)) + (I_2[1]*(k-1)/12 - I_2[2]/2 + I_2[3]*Mu(k) +I_2[4]*Epsilon(k) + I_2[5]*KroneckerDelta(k, 2) - CM_2) / 2;
  end if;
end function;

BCDimensionLoop := function(N, ell, BD)
  I_0, I_1, I_2, CM_1, CM_2 := BCParameters(N, ell);
  for k in [2..BD] do
    print k, BCDimension(I_0, I_1, I_2, CM_1, CM_2, k);
  end for;
  return "Done!";
end function;

newforms := function(N, ell, k)
  I_0, I_1, I_2, CM_1, CM_2 := BCParameters(N, ell);
  return BCDimension(I_0, I_1, I_2, CM_1, CM_2, k);
end function;

allbcd := function(N, ell, k)
  if N eq 1 then
	SkN := newforms(N, ell, k);
  else
    SkNold := 0;
    for M in Divisors(N) do
      if M lt N then
	SkM := newforms(M, ell, k);   /* $$(M, ell, k) would yield double counts*/
	SkNold := SkNold + #Divisors(Round(N/M))*SkM;
      end if;
    end for;
    SkN := SkNold +newforms(N, ell, k);
  end if;
  return SkN;
end function;



