//this only works for CM forms whose local type at ell | Disc is
//principal or supercuspidal of the kind descriped in FGT.
//Furthermore the level N and the discriminant D must be coprime.
//The nebentypus is assumed trivial.

CMsAtInert := function(q, m)
  if m eq 1 then
    return q;
  else
    return q^(m-2)*(q^2-1);
  end if;
end function;

CMsAtSplit := function(p, m)
  if m eq 1 then
    return p-2;
  else
    return p^(m-2)*(p-1)^2;
  end if;
end function;

CMsAtRamified := function(ell, e)
  if (e eq 1) or (e eq 2) then
    return 1;
  else
    return 0;
  end if;
end function;

NumberOfCMformsByK := function(N, D)
  if (N mod D) ne 0 then
    return 0;
  end if;
  Fs := Factorization(N);
  ans := 1;
  K := QuadraticField(-D);
  OK := Integers(K);
  for fct in Fs do
    Ps := Factorization(fct[1]*OK);
    if (#Ps eq 1) and (Ps[1][2] eq 1) then
      if IsOdd(fct[2]) then
        return 0;
      else
        ans *:= CMsAtInert(fct[1], fct[2] div 2);
      end if;
    elif #Ps eq 2 then
      if IsOdd(fct[2]) then
        return 0;
      else
        ans *:= CMsAtSplit(fct[1], fct[2] div 2);
      end if;
    else
      ans *:= CMsAtRamified(fct[1], fct[2]);
    end if;
  end for;
  return ClassNumber(K) * ans;
end function;


