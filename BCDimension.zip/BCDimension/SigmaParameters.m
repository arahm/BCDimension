//Odd discriminant and level coprime to it (in particular even N), trivial Nebentypus.

Epsilon := function(n)
  if IsEven(n) then
    return (-1)^(n div 2) * (1/4);
  else
    return 0;
  end if;
end function;

Mu := function(n)
  if (n mod 3) eq 1 then
    return 0;
  elif (n mod 3) eq 2 then
    return -1/3;
  else
    return 1/3;
  end if;
end function;

lambda := function(r_p, s_p, p)
  if r_p eq 0 then
    return 1;
  elif r_p lt 2*s_p then
    return 2 * p ^ (r_p - s_p);
  else
    if IsEven(r_p) then
      return p ^ (r_p div 2) + p ^((r_p div 2) - 1);
    else
      return 2 * p ^(r_p div 2);
    end if;
  end if;
end function;

//Only for Gamma_0(N)
U_N_dim := function(N)
  ans := 1;
  for f in Factorization(N) do
    ans := ans * lambda(f[2], 0, f[1]);
  end for;
  return ans;
end function;

sigma_dim := function(N)
  ans := N;
  for f in Factorization(N) do
    ans := (ans div f[1]) * (f[1] + 1);
  end for;
  return ans;
end function;

////////////////////////////////////// I_1 /////////////////////////////////
I_1_pow := function(p, e)
  if e eq 0 then
    return 1;
  else
    return p^(e - 1) * (p + 1);
  end if;
end function;

///////////////////////////////////// I_2 ////////////////////////////////////
I_2_pow := function(p, e)
  return lambda(e, 0, p);
end function;

///////////////////////////////////// I_3 ////////////////////////////////////
// elements of order 3 ///////////////////////////////////////////////////////
I_3_pow := function(p, e)
  if e eq 0 then
    return 1;
  elif p ne 3 then//check anything after this!!!
    return KroneckerSymbol(-3, p) + 1;
  elif e eq 1 then
    return 1;
  else
    return 0;
  end if;
end function;

///////////////////////////////////// I_4 ////////////////////////////////////
// elements of order 4 ///////////////////////////////////////////////////////
I_4_pow := function(p, e)
  if e eq 0 then
    return 1;
  elif p ne 2 then//check anything after this!!!
    return KroneckerSymbol(-1, p) + 1;
  elif e eq 1 then
    return 1;
  else
    return 0;
  end if;
end function;

//////////////////////////////////// I_5 ///////////////////////////////////////
//This is not checked!!!!
I_5_pow := function(p, e)
  return 1;
  //if e eq 0 then
  //  return 1;
  //elif p gt 2 then//check anything after this!!!
  //  return KroneckerDelta(-1, p) + 1;
  //else
  //  return 0;
  //end if;
end function;

//////////////////////////////////// I_all ///////////////////////////////////////
I_all_pow_new := function(p, e)
    if e eq 0 then
    return [I_1_pow(p, 0), I_2_pow(p,e), I_3_pow(p, 0), I_4_pow(p,e), I_5_pow(p, 0)];
  elif e eq 1 then
    return [I_1_pow(p, 1) - 2 * I_1_pow(p, 0), I_2_pow(p, 1) - 2 * I_2_pow(p, 0), I_3_pow(p, 1) - 2 * I_3_pow(p, 0), I_4_pow(p, 1) - 2 * I_4_pow(p, 0), I_5_pow(p, 1) - 2 * I_5_pow(p, 0)];
  else
    return [I_1_pow(p, e) - 2 * I_1_pow(p, e - 1) + I_1_pow(p, e - 2), I_2_pow(p, e) - 2 * I_2_pow(p, e - 1) + I_2_pow(p, e - 2), I_3_pow(p, e) - 2 * I_3_pow(p, e - 1) + I_3_pow(p, e - 2), I_4_pow(p, e) - 2 * I_4_pow(p, e - 1) + I_4_pow(p, e - 2), I_5_pow(p, e) - 2 * I_5_pow(p, e - 1) + I_5_pow(p, e - 2)];
  end if;
end function;

I_all_new := function(N)
  ans := [1, 1, 1, 1, 1];
  for fs in Factorization(N) do
    I_p := I_all_pow_new(fs[1], fs[2]);
    //print fs, I_p;
    for i in [1, 2, 3, 4, 5] do
      ans[i] := ans[i] * I_p[i];
    end for;
  end for;
  return ans;
end function;

//////////////////////////////////// Base Change //////////////////////////////////////
//The component at some p | D the discriminant ////////////////////////////////////////
trS4_PS := function(q)  //only for quad chars!
  if ((q mod 4) eq 3)  then
    return 0;
  else
    return 2*(-1)^((q-1) div 4);
  end if;
end function;

trS3_PS := function(q)  //Does not work for non quad chars
  if ((q mod 3) eq 2) then
    return 0;
  elif ((q mod 3) eq 1) then
    return 2;
  else
    return 1;
  end if;
end function;

trS4_SC := function(p)
  if (p mod 4) eq 3 then
    return 2*(-1)^((p-3) div 4);
  else
    return 0;
  end if;
end function;

trS3_SC := function(p)
  if (p mod 3) eq 1 then
    return 0;
  elif  (p mod 3) eq 2 then
    return -2;
  else
    return -1;
  end if;
end function;

I_all_ell := function(ell)
  ell_0 := [1, 1, 1, 1, 1];
  ell_1 := [ell + 1, 2, trS3_PS(ell), trS4_PS(ell), -1];
  ell_2 := [ell - 1, 0, trS3_SC(ell), trS4_SC(ell), 0];
  return ell_0, ell_1, ell_2;
end function;

///////////////////////////////// All together ////////////////////////////////////////
//Only works for odd prime discriminant!!! ////////////////////////////////////////////
I_all_bc := function(N, ell)
  I_all_N := I_all_new(N);
  ell_0, ell_1, ell_2 := I_all_ell(ell);
  ans_0 := [0, 0, 0, 0, 0];
  ans_1 := [0, 0, 0, 0, 0];
  ans_2 := [0, 0, 0, 0, 0];
  for i in [1, 2, 3, 4, 5] do
    ans_0[i] := I_all_N[i] * ell_0[i];
    ans_1[i] := I_all_N[i] * ell_1[i];
    ans_2[i] := I_all_N[i] * ell_2[i];
  end for;
  return ans_0, ans_1, ans_2;
end function;
