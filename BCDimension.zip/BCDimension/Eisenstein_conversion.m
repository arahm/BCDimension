// The dimension of the base change part of the cuspidal space 
// is being calculated with the function allbcd(N, ell, k), where
// N is the level, ell is the prime discriminant (coprime to N) and
// k is the weight.
// To compare with the cohomology, add the Eisenstein contribution.

// Attention: Only prime discriminant > 3 is implemented correctly !!!!!!!!!!

load "CMs.m";
load "SigmaParameters.m";
load "tools.txt";
disc := -7;
K<w>:=QuadraticField(disc); 
One := get_ideal_from_hnf(K,[1,0,1]);

BCParameters := function(N, ell)
  I_0, I_1, I_2 := I_all_bc(N, ell);
  CM_1 := NumberOfCMformsByK(N*ell, ell);
  CM_2 := NumberOfCMformsByK(N*ell^2, ell);
  return I_0, I_1, I_2, CM_1, CM_2;
end function;

BCDimension := function(I_0, I_1, I_2, CM_1, CM_2, k)
  if IsOdd(k) then
    return (I_1[1]*(k-1)/12 - I_1[2]/2 + I_1[3]*Mu(k) +I_1[4]*Epsilon(k) + I_1[5]*KroneckerDelta(k, 2) - CM_1) / 2;
  else
    return (I_0[1]*(k-1)/12 - I_0[2]/2 + I_0[3]*Mu(k) +I_0[4]*Epsilon(k) + I_0[5]*KroneckerDelta(k, 2)) + (I_2[1]*(k-1)/12 - I_2[2]/2 + I_2[3]*Mu(k) +I_2[4]*Epsilon(k) + I_2[5]*KroneckerDelta(k, 2) - CM_2) / 2;
  end if;
end function;

BCDimensionLoop := function(N, ell, BD)
  I_0, I_1, I_2, CM_1, CM_2 := BCParameters(N, ell);
  for k in [2..BD] do
    print k, BCDimension(I_0, I_1, I_2, CM_1, CM_2, k);
  end for;
  return "Done!";
end function;

newBCforms := function(N, ell, k)
  I_0, I_1, I_2, CM_1, CM_2 := BCParameters(N, ell);
  return BCDimension(I_0, I_1, I_2, CM_1, CM_2, k);
end function;


/*  Number of cusps for Gamma0(I), where I is an ideal in the ring of integers of K  */
CuspNumber:=function(K,I)

      O<z>:=Integers(K);

      if Discriminant(K) eq -4 then U:={1,z,-1,-z};
      elif Discriminant(K) eq -3 then U:={z,z^2,z^3,z^4,z^5,z^6};
      else U:={1,-1};
      end if;


      sum:=0;
      for d in Divisors(I) do
         R,h:=quo<O|GCD(d,I/d)>;
         sum:=sum+(#UnitGroup(R)/#h(U));
     end for;
      return ClassNumber(K)*sum;
end function;


load "database_full_dims.txt";
	
EisensteinSubstraction := procedure()
  /* Write a cusp form space database, substracting the Eisenstein part and shifting the weight to modular forms. */  
  cuspspacesdatabase := Open ("cuspspacesdatabase" cat IntegerToString(-7) cat ".txt", "w");
  Puts(cuspspacesdatabase, "cuspspacesdatabase := [ \n");
  for j in [1..#data-1] do
    R := data[j];
    K := QuadraticField(R[1]);
    M := get_ideal_from_hnf(K,[R[2],R[3],R[4]]);
    k := R[5]+2;
    if R[5] eq 0 then
		Eisenstein := CuspNumber(K,M) -1;
    else
		Eisenstein := CuspNumber(K,M);
    end if;
    SkM := R[6]-Round(Eisenstein); 
    Puts(cuspspacesdatabase, "[" cat IntegerToString(R[1]) cat "," 
				cat IntegerToString(R[2]) cat "," 
				cat IntegerToString(R[3]) cat "," 
				cat IntegerToString(R[4]) cat "," 
				cat IntegerToString(k) cat "," 
				cat IntegerToString(SkM) cat "," 
				cat IntegerToString(R[6]) cat "], \n" );
  end for;
  j := #data;
    R := data[j];
    K := QuadraticField(R[1]);
    M := get_ideal_from_hnf(K,[R[2],R[3],R[4]]);
    k := R[5]+2;
    if R[5] eq 0 then
		Eisenstein := CuspNumber(K,M) -1;
    else
		Eisenstein := CuspNumber(K,M);
    end if;
    SkM := R[6]-Round(Eisenstein); 
    Puts(cuspspacesdatabase, "[" cat IntegerToString(R[1]) cat "," 
				cat IntegerToString(R[2]) cat "," 
				cat IntegerToString(R[3]) cat "," 
				cat IntegerToString(R[4]) cat "," 
				cat IntegerToString(k) cat "," 
				cat IntegerToString(SkM) cat "," 
				cat IntegerToString(R[6]) cat "] \n" );
  Puts(cuspspacesdatabase, "];");
end procedure;

EisensteinSubstraction();

load "cuspspacesdatabase-7.txt";


DatabaseLookup := function(M, ell, k)
  SkM := -777;
  hnf := HNF_basis(M);
  for j in [1..#cuspspacesdatabase] do
    R := cuspspacesdatabase[j];
    if R[2] eq hnf[1] then
     if R[3] eq hnf[2] then
      if R[4] eq hnf[3] then
       if R[5] eq k then
  	if -ell eq R[1] then
		SkM := R[6];
	end if;
       end if;
      end if;
     end if;
    end if;
  end for;
  if SkM eq -777 then 
  	SkM := "not_found";
	print "Error, did not find S_",k," of ",M;
  end if;
  return SkM;
end function;


/* Feed an ideal N into the following, database-bound recursive function. */
oldforms := function(N, ell, k)
  if N eq One then
	SkNold := 0;
  else
    SkNold := 0;
    for M in Divisors(N) do
      if M ne N then
	SkMold := $$(M, ell, k); /* recursive function call */
	SkM := DatabaseLookup(M, ell, k);
	SkNold := SkNold + #Divisors(N/M)*(SkM-SkMold);
      end if;
    end for;
  end if;
  return SkNold;
end function;

WriteNewformDatabase := procedure()
  /* Write a new form space database, substracting the old form part. */  
print "Discriminant | levelHNF | weight | total | all cuspidal | new cuspidal | newBC | newCM+genuine \n";
  newformsdatabase := Open ("newformsdatabase" cat IntegerToString(-7) cat ".txt", "w");
  Puts(newformsdatabase, "print \" remove the last comma in the second-last line of newformsdatase\" \n");
  Puts(newformsdatabase, "newformsdatabase := [ \n");
  for j in [1..#cuspspacesdatabase] do
    R := cuspspacesdatabase[j];
    /* Check if the level is totally real: */
    if R[4]^2 eq R[2] then 
      /* check also that the prime discriminant is coprime to N */
      if GCD(-R[1],R[4]) eq 1 then 
    	ell := -R[1];
    	N := get_ideal_from_hnf(K,[R[2],R[3],R[4]]);
    	k := R[5];
  	allnewforms := R[6] -oldforms(N,ell,k);
        newBC := newBCforms(R[4], ell, k);
  	print R[1]," | [",R[2],",",R[3],",",R[4],"] | ",k," | ",R[7], " | ",R[6], " | ",allnewforms, " | ",newBC, " | ",allnewforms-newBC,"\n";
	Puts(newformsdatabase, "[" cat IntegerToString(R[1]) cat "," 
				cat IntegerToString(R[2]) cat "," 
				cat IntegerToString(R[3]) cat "," 
				cat IntegerToString(R[4]) cat "," 
				cat IntegerToString(k) cat "," 
				cat IntegerToString(allnewforms) cat "," 
				cat IntegerToString(Round(newBC)) cat "], \n" );

    end if;
  end if;
  end for;
end procedure;

WriteNewformDatabase();
